import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { movie } from "../../models/movie.interface";
import { HttpClient } from "@angular/common/http";
import { ConfigService } from "./config.service";

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private urlOfTopRatedMovies;
  private urlOfGetUpcomingMovies;

  constructor(private http:HttpClient,private configService:ConfigService) {

    let apiUrls                 = this.configService.moviesApp.apiUrls;
    this.urlOfTopRatedMovies    = apiUrls.topRatedMovies;
    this.urlOfGetUpcomingMovies = apiUrls.upComingMovies;
    
   }

  getTopRatedMovies(currPage:number):Observable<movie>
  {
    return this.http.get<movie>(this.urlOfTopRatedMovies+"&page="+currPage);
  }
  getUpcomingMovies(currPage:number):Observable<movie>
  {
    return this.http.get<movie>(this.urlOfGetUpcomingMovies+"&page="+currPage);
  }
}
