export class ConfigService {

  public moviesApp = {
    apiUrls: {
      topRatedMovies:
        "https://api.themoviedb.org/3/movie/top_rated?api_key=3398c1d4033de5acb830794d30f4db25&language=en-US",
      upComingMovies:
        "https://api.themoviedb.org/3/movie/upcoming?api_key=3398c1d4033de5acb830794d30f4db25&language=en-US",
      baseImgUrl: "https://image.tmdb.org/t/p/original/"
    },

    paginationControls: {
      topRated: {
        totItemsPerPage: 20,
      },
      upcomingMovies: {
        totItemsPerPage: 20,
      },
    }

  };

  constructor() {}
}
