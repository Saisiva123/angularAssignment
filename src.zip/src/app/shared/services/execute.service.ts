import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})

export class ExecuteService {

  constructor(private dataService:DataService) { }

  public topRatedMoviesData = new BehaviorSubject(null);
  topRatedMoviesDataObserver= this.topRatedMoviesData.asObservable();

  public upcomingMoviesData = new BehaviorSubject(null);
  upcomingMoviesDataObserver = this.upcomingMoviesData.asObservable();

  updateTopRatedMovies(currPage:number)
  {
    this.dataService.getTopRatedMovies(currPage).subscribe(data=>
      {
        this.topRatedMoviesData.next(data);
      });
  }
  updateUpcomingMovies(currPage:number)
  {
    this.dataService.getUpcomingMovies(currPage).subscribe(data=>
      {
        this.upcomingMoviesData.next(data);
      });
  }

}
