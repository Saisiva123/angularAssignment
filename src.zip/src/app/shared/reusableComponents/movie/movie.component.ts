import { Component, Input, OnInit } from '@angular/core';
import { ConfigService } from '../../services/config.service';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {

  @Input() movieDetails:any;
  baseImgUrl:string;

  constructor(private configService:ConfigService) { }

  ngOnInit(): void {
    this.baseImgUrl=this.configService.moviesApp.apiUrls.baseImgUrl;
  }

}
