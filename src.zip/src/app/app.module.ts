import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { routingComponents } from "./app-routing.module";
import { SlickCarouselModule } from "ngx-slick-carousel";
import { TopRatedComponent } from "./home-page/top-rated/top-rated.component";
import { UpcomingComponent } from "./home-page/upcoming/upcoming.component";
import { MovieComponent } from "./shared/reusableComponents/movie/movie.component";
import { HttpClientModule } from "@angular/common/http";
import { NgxPaginationModule } from "ngx-pagination";
import { ConfigService } from "./shared/services/config.service";
import { DataService } from "./shared/services/data.service";
import { ExecuteService } from "./shared/services/execute.service";

@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    TopRatedComponent,
    UpcomingComponent,
    MovieComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SlickCarouselModule,
    HttpClientModule,
    NgxPaginationModule,
  ],
  providers: [ConfigService, DataService, ExecuteService],
  bootstrap: [AppComponent],
})
export class AppModule {}
