import { Component, OnInit } from '@angular/core';
import { ConfigService } from 'src/app/shared/services/config.service';
import { ExecuteService } from 'src/app/shared/services/execute.service';

@Component({
  selector: 'app-upcoming',
  templateUrl: './upcoming.component.html',
  styleUrls: ['./upcoming.component.css']
})
export class UpcomingComponent implements OnInit {

  totItemsPerPage: number;
  upcomingMovieList=[];
  currPageItems: any;
  p: number = 1;

  constructor( private executeService:ExecuteService,private configService:ConfigService) { }

  ngOnInit(): void {
    this.totItemsPerPage=this.configService.moviesApp.paginationControls.upcomingMovies.totItemsPerPage;
    this.executeService.upcomingMoviesDataObserver.subscribe(data => {
      data?this.updateMovieList(data):null;
    })
    this.executeService.updateUpcomingMovies(this.p);
  }
  pageChange($event) {
    this.p = $event;
    this.executeService.updateUpcomingMovies(this.p);
  }
  updateMovieList(data)
  {
    this.upcomingMovieList = data.results;
    this.currPageItems = data.total_results;
    this.p = data.page;
  }

}
