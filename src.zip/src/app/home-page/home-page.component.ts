import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-home-page",
  templateUrl: "./home-page.component.html",
  styleUrls: ["./home-page.component.css"],
})
export class HomePageComponent implements OnInit {

  slidesOfBgImages = [
    "../../assets/images/img1.jpg",
    "../../assets/images/img2.jpg",
    "../../assets/images/img3.jpg",
    "../../assets/images/img4.jpg"
  ];

  slideConfig = {
    slidesToShow: 1,
    slidesToScroll: 1,
    dots: true,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 2000,
    pauseOnFocus: false,
    pauseOnHover: false,
    pauseOnDotsHover: false,
    speed: 1000,
    fade: true,
    cssEase: "linear"
  };

  constructor() {}

  ngOnInit(): void {
  }
 

  
}
