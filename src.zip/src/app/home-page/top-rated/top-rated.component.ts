import { Component, OnInit } from "@angular/core";
import { ConfigService } from 'src/app/shared/services/config.service';
import { ExecuteService } from "src/app/shared/services/execute.service";

@Component({
  selector: "app-top-rated",
  templateUrl: "./top-rated.component.html",
  styleUrls: ["./top-rated.component.css"],
})
export class TopRatedComponent implements OnInit {

  topRatedMovieList = [];
  currPageItems: any;
  totItemsPerPage: number;
  p: number = 1;

  constructor(private executeService: ExecuteService,private configService:ConfigService) {}

  ngOnInit(): void {
    this.totItemsPerPage=this.configService.moviesApp.paginationControls.topRated.totItemsPerPage;
    this.executeService.topRatedMoviesDataObserver.subscribe((data) => {
      data ? this.updateMovieList(data) : null;
    });
    this.executeService.updateTopRatedMovies(this.p);
  }

  pageChange($event) {
    this.p = $event;
    this.executeService.updateTopRatedMovies(this.p);
  }
  updateMovieList(data) {
    this.topRatedMovieList = data.results;
    this.currPageItems = data.total_results;
    this.p = data.page;
  }
}
